#!/usr/bin/env python

import prompt
from brain_games.welc import welcome


def main():
    print(welcome())

if __name__ == '__main__':  
    main()
