#!/usr/bin/env python
"""Must be imported by brain_games.py."""

import prompt

def welcome():
    """Return user's welcome by using prompt.string package."""
    name = prompt.string('Welcome to the Brain Games!\nMay i have your name? ')
    return 'Hello, {}!'.format(name)
